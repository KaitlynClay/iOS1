import UIKit

var greeting = "Hello, playground"
var answer = 8 + 10
print(greeting)
print(answer)
